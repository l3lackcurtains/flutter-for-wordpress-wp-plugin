# Loan Calculator Plugin for Wordpress

Apply for Loan
-----------------------------
[loancalcapply linkto="#"]
-----------------------------

Loan calculator with submission form
------------------------------
[loancalc]
------------------------------
